<?php

/**
 * OpenProvider Registar module
 *
 * @copyright Copyright (c) Openprovider 2018
 */

/**
 * Hooks
 * ----------------
 * 
 * Instead of mapping routes automagically to controllers, we use
 * a whitelist of routes with the controllers mapped.
 * 
 * If the string only contains a-zA-Z0-9_, the namespace will be 
 * guessed and added. 
 */
return [
    [
        'hookPoint' => 'ClientAreaPageDomainDetails',
        'priority' =>  1,
        'controller' => 'DomainController@saveDomainEdit'
    ],
    [
        'hookPoint' => 'DomainEdit',
        'priority' =>  1,
        'controller' => 'DomainController@saveDomainEdit'
    ],
    // [
    //     'hookPoint' => 'ClientAreaPrimarySidebar',
    //     'priority' =>  1,
    //     'controller' => 'NavigationController@hideRegistrarLock'
    // ],
    [
        'hookPoint' => 'AdminHomeWidgets',
        'priority' =>  1,
        'controller' => 'AdminWidgetController@showBalanceWidget'
    ],
    [
        'hookPoint' => 'AdminHomeWidgets',
        'priority' =>  2,
        'controller' => 'AdminWidgetController@showCrossSellWidget'
    ],
    [
        'hookPoint' => 'AdminAreaPage',
        'priority' =>  1,
        'controller' => 'AdminWidgetController@handleCrossSellDismiss'
    ],
    [
        'hookPoint' => 'ClientAreaPageDomainDNSManagement',
        'priority' => 10,
        'controller' => 'DnsNotificationController@notify'
    ],
    [
        'hookPoint' => 'ClientAreaPrimarySidebar',
        'priority'  => 1,
        'controller' => 'ClientAreaPrimarySidebarController@show'
    ],
    [
        'hookPoint' => 'ClientAreaPageDomainDNSManagement',
        'priority'  => 1,
        'controller' => 'DnsAuthController@redirectDnsManagementPage'
    ],
    [
        'hookPoint' => 'AdminClientProfileTabFields',
        'priority'  => 1,
        'controller' => 'AdminClientProfileTabController@additionalFields',
    ],
    [
        'hookPoint' => 'AdminClientProfileTabFieldsSave',
        'priority'  => 1,
        'controller' => 'AdminClientProfileTabController@saveFields',
    ],
    [
        'hookPoint' => 'ShoppingCartCheckoutOutput',
        'priority'  => 1,
        'controller' => 'ShoppingCartController@checkoutOutput',
    ],
    [
        'hookPoint' => 'ShoppingCartValidateCheckout',
        'priority'  => 1,
        'controller' => 'ShoppingCartController@preCheckout',
    ],
    [
        'hookPoint' => 'ContactAdd',
        'priority'  => 1,
        'controller' => 'ContactController@add',
    ],
    [
        'hookPoint' => 'ContactDelete',
        'priority'  => 1,
        'controller' => 'ContactController@delete',
    ],
    [
        'hookPoint' => 'ContactEdit',
        'priority'  => 1,
        'controller' => 'ContactController@edit',
    ],
    [
        'hookPoint' => 'ClientAreaFooterOutput',
        'priority'  => 1,
        'controller' => 'ClientAreaFooterController@output',
    ],
    [
        'hookPoint' => 'ClientAreaDomainDetailsOutput',
        'priority' => 1,
        'controller' => 'DomainLockingEnabledController@handleDomainLockingClientArea',
    ],
    [
        'hookPoint' => 'ClientAreaPrimarySidebar',
        'priority' => 1,
        'controller' => 'DomainLockingEnabledController@handleDomainLockingClientSidebar',
    ],
    [
        'hookPoint' => 'AdminAreaFooterOutput',
        'priority' => 1,
        'controller' => 'DomainLockingEnabledController@handleDomainLockingAdminArea',
    ],
    [
        'hookPoint' => 'AdminAreaHeaderOutput',
        'priority'  => 1,
        'controller'=> 'AdminAreaHeaderOutputController@output',
    ],
    [
        'hookPoint' => 'AdminClientDomainsTabFields',
        'priority'  => 1,
        'controller'=> 'DnssecToggleController@output',
    ],
    [
        'hookPoint' => 'AdminClientDomainsTabFieldsSave',
        'priority'  => 1,
        'controller'=> 'DnssecToggleController@save',
    ],
    [
        'hookPoint' => 'AdminAreaFooterOutput',
        'priority' => 1,
        'controller' => 'DnssecToggleController@footer',
    ],
    [
        'hookPoint' => 'AfterRegistrarRegistration',
        'priority'  => 1,
        'controller' => 'DomainController@updateExpiryDateAfterRegistration',
    ],
    [
        'hookPoint' => 'AfterRegistrarTransfer',
        'priority'  => 1,
        'controller' => 'DomainController@updateExpiryDateAfterTransfer',
    ],
    [
        'hookPoint' => 'AdminAreaFooterOutput',
        'priority'  => 1,
        'controller' => 'AdminAreaFooterController@output',
    ],
    [
        'hookPoint' => 'AdminAreaFooterOutput',
        'priority'  => 2,
        'controller' => 'AdminAreaFooterController@makeLocaleReadonly',
    ],
    [
        'hookPoint' => 'AdminClientDomainsTabFieldsSave',
        'priority'  => 1,
        'controller' => 'AdminClientDomainsTabController@save',
    ],
    [
        'hookPoint' => 'ClientAreaPageCart',
        'priority'  => 1,
        'controller'=> 'ShoppingCartController@filterDomainConfigFields',
    ],
    [
        'hookPoint' => 'ClientAreaFooterOutput',
        'priority'  => 2,
        'controller' => 'ShoppingCartController@injectDomainConfigFieldFilters',
    ],
];

<?php

namespace OpenProvider\WhmcsRegistrar\Controllers\System;

use WHMCS\ClientArea;
use WHMCS\Authentication\CurrentUser;
use WHMCS\Config\Setting;
use WHMCS\Database\Capsule;
use OpenProvider\API\ApiHelper;
use OpenProvider\API\Domain;
use OpenProvider\WhmcsRegistrar\helpers\DomainFullNameToDomainObject;
use OpenProvider\WhmcsRegistrar\helpers\DnssecManagement;
use OpenProvider\WhmcsRegistrar\src\Configuration;
use WeDevelopCoffee\wPower\Core\Core;
use WeDevelopCoffee\wPower\Controllers\BaseController;

class DnsManagementPageController extends BaseController
{
    const PAGE_TITLE = 'DNS Management';
    const PAGE_NAME  = 'DNS Management';
    const MODULE_NAME = 'dnsmanagement';
    const CSRF_SESSION_KEY = 'opDnsManagementCsrfToken';

    /**
     * @var ApiHelper
     */
    private $apiHelper;

    private DnsController $dnsController;
    private Domain $opDomain;

    public function __construct(Core $core, ApiHelper $apiHelper, DnsController $dnsController, Domain $opDomain)
    {
        parent::__construct($core);
        $this->apiHelper = $apiHelper;
        $this->dnsController = $dnsController;
        $this->opDomain = $opDomain;
    }

    public function show($params)
    {
        $ca = new ClientArea();
        $ca->setPageTitle(self::PAGE_NAME);

        $currentUser = new CurrentUser();
        $authUser = $currentUser->user();
        $selectedClient = $currentUser->client();

        if (!$authUser || !$selectedClient) {
            $this->redirectUserAway();
            return;
        }

        $domainId = (int) ($_GET['domainid'] ?? 0);

        $domain = Capsule::table('tbldomains')
            ->where('id', $domainId)
            ->where('userid', $selectedClient->id)
            ->first();

        if (!$domain) {
            $this->redirectUserAway();
            return;
        }
        $dnssecEnabled = DnssecManagement::getFlag((int)$domainId) === 1;
        $domainObj = DomainFullNameToDomainObject::convert($domain->domain);
        $params['sld'] = $domainObj->name;
        $params['tld'] = $domainObj->extension;

        // Delete records
        if ($_SERVER['REQUEST_METHOD'] === 'POST'
            && ($_POST['op_action'] ?? '') === 'deleteRecord') {

            header('Content-Type: application/json; charset=utf-8');

            $currentUser = new \WHMCS\Authentication\CurrentUser();
            if (!$currentUser->user() || !$currentUser->client()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Not authenticated']);
                return;
            }

            // CSRF validation
            if (!$this->verifyCsrfToken()) {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
                return;
            }

            try {
                $hostname = html_entity_decode(trim((string) ($_POST['hostname'] ?? '')), ENT_QUOTES, 'UTF-8');
                $type     = strtoupper(trim((string) ($_POST['type'] ?? '')));
                $address  = html_entity_decode(trim((string) ($_POST['address'] ?? '')), ENT_QUOTES, 'UTF-8');
                $priority = html_entity_decode(trim((string) ($_POST['priority'] ?? '')), ENT_QUOTES, 'UTF-8');

                if ($type === '' || $address === '') {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => 'Invalid record']);
                    return;
                }
                $opDomain = clone $this->opDomain;
                $opDomain->load([
                    'name'      => $params['sld'],
                    'extension' => $params['tld'],
                ]);

                $rec = [
                    'type'  => $type,
                    'name'  => $hostname,
                    'value' => $address,
                    'ttl'   => \OpenProvider\API\APIConfig::$dnsRecordTtl,
                ];

                if (in_array($type, ['MX','SRV'], true) && $priority !== '' && strtoupper($priority) !== 'N/A') {
                    $rec['prio'] = (int)$priority;
                }

                $this->apiHelper->removeDnsRecord($opDomain, $rec);
                echo json_encode(['success' => true]);
                return;

            } catch (\Exception $e) {
                http_response_code(500);
                echo json_encode([
                    'success' => false,
                    'error' => $e->getMessage()
                ]);
            }
            return; 
        }

        // save DNS records
        $isAjaxOrJsonRequest = false;
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            $isAjaxOrJsonRequest = true;
        } elseif (!empty($_SERVER['HTTP_ACCEPT']) && stripos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false) {
            $isAjaxOrJsonRequest = true;
        }
        if (
            $_SERVER['REQUEST_METHOD'] === 'POST'
            && (
                empty($_POST['op_action'])
                || ($_POST['op_action'] ?? '') === 'saveRecords'
            )
            && $isAjaxOrJsonRequest
        ) {

            header('Content-Type: application/json; charset=utf-8');

            // auth check
            $currentUser = new \WHMCS\Authentication\CurrentUser();
            if (!$currentUser->user() || !$currentUser->client()) {
                http_response_code(401);
                echo json_encode(['success' => false, 'error' => 'Not authenticated']);
                return;
            }

            // CSRF validation
            if (!$this->verifyCsrfToken()) {
                http_response_code(403);
                echo json_encode(['success' => false, 'error' => 'Invalid CSRF token']);
                return;
            }

            try {
                $params['dnsrecords'] = $this->buildDnsRecordsFromPost();
                $result = $this->dnsController->save($params);

                if (is_array($result) && isset($result['error'])) {
                    http_response_code(400);
                    echo json_encode(['success' => false, 'error' => $result['error']]);
                    return;
                }

                // Get updated records (fresh from API)
                $dnsRecords = $this->dnsController->get($params);

                echo json_encode([
                    'success' => true,
                    'dnsrecords' => $dnsRecords,
                ]);
                return;
            } catch (\Throwable $e) {
                http_response_code(500);
                echo json_encode(['success' => false, 'error' => $e->getMessage()]);
                return;
            }
        }

        render_page:

        $supportsDnssec = false;

        try {
            $supportsDnssec = $this->apiHelper->supportsDnssec($params['tld']);
        } catch (\Throwable $e) {
            $supportsDnssec = false;
        }

        // load DNS records for the domain
        $dnsRecords = $this->dnsController->get($params);

        $ca->assign('dnsrecords', $dnsRecords);
        $ca->assign('domainId', $domainId);
        $ca->assign('jsModuleUrl', Configuration::getJsModuleUrl(self::MODULE_NAME));

        //  Breadcrumbs 
        $ca->addToBreadCrumb('index.php', \Lang::trans('globalsystemname'));
        $ca->addToBreadCrumb('clientarea.php', \Lang::trans('clientareatitle'));
        $ca->addToBreadCrumb('clientarea.php?action=domains', \Lang::trans('clientareanavdomains'));
        $ca->addToBreadCrumb(
            'clientarea.php?action=domaindetails&id=' . $domainId,
            $domain->domain
        );
        $ca->addToBreadCrumb('dnsmanagement.php', self::PAGE_NAME);

        $ca->initPage();
        $ca->requireLogin();

        // Sidebar
        $primarySidebar = \Menu::primarySidebar('domainView');

        $primarySidebar->getChild('Domain Details Management')
            ->addChild('Overview')
            ->setLabel(\Lang::trans('overview'))
            ->setUri("clientarea.php?action=domaindetails&id={$domainId}")
            ->setOrder(0);

        $primarySidebar->getChild('Domain Details Management')
            ->addChild('Auto Renew')
            ->setLabel(\Lang::trans('domainsautorenew'))
            ->setUri("clientarea.php?action=domaindetails&id={$domainId}#tabAutorenew")
            ->setOrder(10);

        $primarySidebar->getChild('Domain Details Management')
            ->addChild('Nameservers')
            ->setLabel(\Lang::trans('orderservernameservers'))
            ->setUri("clientarea.php?action=domaindetails&id={$domainId}#tabNameservers")
            ->setOrder(20);

        $primarySidebar->getChild('Domain Details Management')
            ->addChild('Addons')
            ->setLabel(\Lang::trans('domainaddons'))
            ->setUri("clientarea.php?action=domaindetails&id={$domainId}#tabAddons")
            ->setOrder(30);

        $primarySidebar->getChild('Domain Details Management')
            ->addChild('Contact Information')
            ->setLabel(\Lang::trans('domaincontactinfo'))
            ->setUri("clientarea.php?action=domaincontacts&domainid={$domainId}")
            ->setOrder(40);

        if (isset($domain) && $domain->dnsmanagement) {
            $primarySidebar->getChild('Domain Details Management')
                ->addChild('DNS Management')
                ->setLabel(\Lang::trans('domaindnsmanagement'))
                ->setUri("dnsmanagement.php?domainid={$domainId}")
                ->setOrder(50);
        }
        if ($dnssecEnabled && $supportsDnssec) {
            $primarySidebar->getChild('Domain Details Management')
                ->addChild('DNSSEC')
                ->setLabel(\Lang::trans('dnssectabname'))
                ->setUri("dnssec.php?domainid={$domainId}")
                ->setOrder(100);
        }

        $activeTheme = Setting::getValue('Template');
        $activeTheme = preg_replace('/[^a-zA-Z0-9_-]/', '', (string) $activeTheme);

        $template = '/modules/registrars/openprovider/includes/templates/dnsmanagement.tpl';

        $templatesDir = ROOTDIR . '/templates';
        $templatesDirReal = realpath($templatesDir);

        if ($templatesDirReal !== false && $activeTheme !== '') {
            $candidate = $templatesDirReal . '/' . $activeTheme . '/dnsmanagement.tpl';
            $resolved = realpath($candidate);

            if ($resolved !== false && str_starts_with($resolved, $templatesDirReal . DIRECTORY_SEPARATOR)) {
                $template = 'dnsmanagement';
            }
        }

        $ca->setTemplate($template);
        // Deliberately NOT named 'csrfToken' — WHMCS's own ClientArea::output() appears to auto-populate/overwrite that variable name internally, which is what silently discarded our token.
        $ca->assign('opDnsCsrfToken', $this->getCsrfToken());
        $ca->output();
    }

    private function getCsrfToken(): string
    {
        if (empty($_SESSION[self::CSRF_SESSION_KEY])) {
            $_SESSION[self::CSRF_SESSION_KEY] = bin2hex(random_bytes(32));
        }

        return $_SESSION[self::CSRF_SESSION_KEY];
    }

    private function verifyCsrfToken(): bool
    {
        $submitted = (string) ($_POST['opDnsCsrfToken'] ?? '');

        return !empty($_SESSION[self::CSRF_SESSION_KEY])
            && hash_equals($_SESSION[self::CSRF_SESSION_KEY], $submitted);
    }

    private function buildDnsRecordsFromPost(): array
    {
        $records = [];

        $hosts     = $_POST['dnsrecordhost'] ?? [];
        $types     = $_POST['dnsrecordtype'] ?? [];
        $addresses = $_POST['dnsrecordaddress'] ?? [];
        $priority  = $_POST['dnsrecordpriority'] ?? [];

        foreach ($hosts as $i => $host) {
            $host    = html_entity_decode(trim((string) $host), ENT_QUOTES, 'UTF-8');
            $type    = strtoupper(trim((string) ($types[$i] ?? '')));
            $address = html_entity_decode(trim((string) ($addresses[$i] ?? '')), ENT_QUOTES, 'UTF-8');
            $prio    = html_entity_decode(trim((string) ($priority[$i] ?? '')), ENT_QUOTES, 'UTF-8');

            // Skip completely empty rows
            if ($host === '' && $address === '') {
                continue;
            }

            // Skip invalid records (no type or no address)
            if ($type === '' || $address === '') {
                continue;
            }

            $records[] = [
                'hostname' => $host,
                'type'     => $type,
                'address'  => $address,
                'priority' => $prio,
            ];
        }

        return $records;
    }

    private function redirectUserAway()
    {
        $defaultUrl = Configuration::getServerUrl();

        if (isset($_SERVER['HTTP_REFERER'])) {
            $referer = $_SERVER['HTTP_REFERER'];

            // Only allow redirects within same WHMCS base URL
            if (is_string($referer) && $referer !== '' && strpos($referer, $defaultUrl) === 0) {
                header('Location: ' . $referer);
                return;
            }
        }

        header('Location: ' . $defaultUrl);
    }
}